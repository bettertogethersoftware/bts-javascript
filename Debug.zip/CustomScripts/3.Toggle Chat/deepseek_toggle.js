/*** deepseek ***/

const container = document.querySelector('div.aaff8b8f');
if (container) {
    // Retrieve the computed display style of the container
    const computedDisplay = window.getComputedStyle(container).display;

    // If the container is currently displayed (not 'none'), hide it
    if (computedDisplay !== 'none') {
        container.style.display = 'none';
    } else {
        // Otherwise, remove the inline display style to revert to default
        container.style.display = '';
    }
}

