/*** chatgpt ***/

const form = document.querySelector('form.w-full');
if (form) {
    // Retrieve the computed display style of the form
    const computedDisplay = window.getComputedStyle(form).display;

    // If the form is currently displayed (not 'none'), hide it
    if (computedDisplay !== 'none') {
        form.style.display = 'none';
    } else {
        // Otherwise, remove the inline display style to revert to default
        form.style.display = '';
    }
}
