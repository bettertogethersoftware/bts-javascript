﻿/*** claude ***/
//Validated: //normal:2025-02-19
var targetUrl = "claude";
const currentUrlLowerCase = window.location.href.toLowerCase();
//debug
//alert("currentUrlLowerCase: " + currentUrlLowerCase + ", targetUrl: " + targetUrl);
if (!currentUrlLowerCase.includes(targetUrl))
    return;
/***************/
const startNewChatButton = document.querySelector('a[href="/new"]');
if (startNewChatButton) {
    startNewChatButton.click();
} else {
    console.error("Error: 'Start new chat' button not found");
}