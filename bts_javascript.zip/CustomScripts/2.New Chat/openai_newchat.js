﻿/*** grok ***/
//Validated: 
//normal:2025-02-21
var targetUrl = "openai";
const currentUrlLowerCase = window.location.href.toLowerCase();
// Debug alert to check current URL and target URL
//alert("currentUrlLowerCase: " + currentUrlLowerCase + ", targetUrl: " + targetUrl);
if (!currentUrlLowerCase.includes(targetUrl))
    return;
/**************/


if (!currentUrlLowerCase.includes("assistant")) {
    document.querySelector("button.Wmjjd[data-color='secondary']").click();


} else {
    document.querySelector('.btn.btn-sm.btn-minimal.btn-neutral').click();


}
