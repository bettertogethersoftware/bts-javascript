﻿
/*** anthropic ***/
//Validated:

var targetUrl = "anthropic";
const currentUrlLowerCase = window.location.href.toLowerCase();
//debug
//alert("currentUrlLowerCase: " + currentUrlLowerCase + ", " + "targetUrl: " + targetUrl);
if (!currentUrlLowerCase.includes(targetUrl))
    return;
/***************/

document.querySelector('[data-testid="new-prompt-button"]').click();
