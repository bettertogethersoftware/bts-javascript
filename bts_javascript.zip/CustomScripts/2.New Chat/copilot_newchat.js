﻿/*** copilot ***/
var targetUrl = "copilot";
const currentUrlLowerCase = window.location.href.toLowerCase();
//debug
//alert("currentUrlLowerCase: " + currentUrlLowerCase + ", " + "targetUrl: " + targetUrl);
if (!currentUrlLowerCase.includes(targetUrl))
    return;
/***************/

window.location.href = "https://copilot.microsoft.com/";
