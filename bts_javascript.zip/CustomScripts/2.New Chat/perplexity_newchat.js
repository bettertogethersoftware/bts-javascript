﻿var targetUrl = "perplexity";
const currentUrlLowerCase = window.location.href.toLowerCase();
if (!currentUrlLowerCase.includes(targetUrl)) return;

// Select all clickable containers (with the cursor-pointer class)
const clickableElements = Array.from(document.querySelectorAll('div.cursor-pointer'));

// Find the element that contains "Ctrl" in its inner text, which is part of the keyboard shortcut indicator.
const newThreadElement = clickableElements.find(el => el.innerText.includes("Ctrl"));

if (newThreadElement) {
    newThreadElement.click();
} else {
    console.error("Error: 'New Thread' clickable element not found.");
}