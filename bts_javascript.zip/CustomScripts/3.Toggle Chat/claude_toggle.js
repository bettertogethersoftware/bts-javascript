﻿/*** claude ***/

var targetUrl = "claude";
const currentUrlLowerCase = window.location.href.toLowerCase();
// If current URL doesn’t include the target, do nothing.
if (!currentUrlLowerCase.includes(targetUrl))
    return;
/***************/
// Select the target div (note the escape for the square brackets in "z-[5]")
const targetDiv = document.querySelector('div.sticky.mx-auto.w-full.pt-6.z-\\[5\\]');
if (targetDiv) {
    // Retrieve its computed display style.
    const computedDisplay = window.getComputedStyle(targetDiv).display;

    // Toggle the display: if currently visible, hide it; otherwise, revert.
    if (computedDisplay !== 'none') {
        targetDiv.style.display = 'none';
    } else {
        targetDiv.style.display = '';
    }
}
