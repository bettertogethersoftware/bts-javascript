﻿/*** perplexity ***/

var targetUrl = "perplexity";
const currentUrlLowerCase = window.location.href.toLowerCase();
//debug
//alert("currentUrlLowerCase: " + currentUrlLowerCase + ", " + "targetUrl: " + targetUrl);
if (!currentUrlLowerCase.includes(targetUrl))
    return;
/***************/

// Target the container using a unique class from the HTML element
const container = document.querySelector('div.bottom-mobileNavHeight');
if (container) {
    // Retrieve the computed display style of the container
    const computedDisplay = window.getComputedStyle(container).display;

    // If the container is currently displayed (not 'none'), hide it
    if (computedDisplay !== 'none') {
        container.style.display = 'none';
    } else {
        // Otherwise, remove the inline display style to revert to default
        container.style.display = '';
    }
}
