﻿/*** copilot ***/
var targetUrl = "copilot";
const currentUrlLowerCase = window.location.href.toLowerCase();
// If current URL doesn’t include the target, do nothing.
if (!currentUrlLowerCase.includes(targetUrl))
    return;


const targetDiv = document.querySelector(
    'div.relative.mb-4.flex.w-full.flex-col.items-center.px-3.sm\\:mb-8'
);

if (targetDiv) {
    // Retrieve its computed display style.
    const computedDisplay = window.getComputedStyle(targetDiv).display;

    // Toggle the display: if currently visible, hide it; otherwise, revert.
    if (computedDisplay !== 'none') {
        targetDiv.style.display = 'none';
    } else {
        targetDiv.style.display = '';
    }
} else {
    console.error("Target element not found");
}
