/*** chatgpt ***/
//Validated:
//4o mini:2025-02-19
//o3 mini:2025-02-19
var targetUrl = "chatgpt";
const currentUrlLowerCase = window.location.href.toLowerCase();
//debug
//alert("currentUrlLowerCase: " + currentUrlLowerCase + ", " + "targetUrl: " + targetUrl);
if (!currentUrlLowerCase.includes(targetUrl))
    return;
/***************/
const form = document.querySelector('form.w-full');
if (form) {
    // Retrieve the computed display style of the form
    const computedDisplay = window.getComputedStyle(form).display;

    // If the form is currently displayed (not 'none'), hide it
    if (computedDisplay !== 'none') {
        form.style.display = 'none';
    } else {
        // Otherwise, remove the inline display style to revert to default
        form.style.display = '';
    }
}
