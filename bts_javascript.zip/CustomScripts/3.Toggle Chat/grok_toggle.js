﻿/*** grok ***/

var targetUrl = "grok";
const currentUrlLowerCase = window.location.href.toLowerCase();
//debug
//alert("currentUrlLowerCase: " + currentUrlLowerCase + ", " + "targetUrl: " + targetUrl);
if (!currentUrlLowerCase.includes(targetUrl))
    return;
/***************/
const container = document.querySelector('div.relative.z-40.flex.flex-col.items-center.w-full');
if (container) {
    // Retrieve the computed display style of the container
    const computedDisplay = window.getComputedStyle(container).display;

    // If the container is currently displayed (not 'none'), hide it
    if (computedDisplay !== 'none') {
        container.style.display = 'none';
    } else {
        // Otherwise, remove the inline display style to revert to default
        container.style.display = '';
    }
}
