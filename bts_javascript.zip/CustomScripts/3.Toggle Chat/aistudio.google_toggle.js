﻿/*** aistudio ***/

var targetUrl = "aistudio";
const currentUrlLowerCase = window.location.href.toLowerCase();
//debug
//alert("currentUrlLowerCase: " + currentUrlLowerCase + ", " + "targetUrl: " + targetUrl);
if (!currentUrlLowerCase.includes(targetUrl))
    return;
/***************/
const systemInstructions = document.querySelector('ms-system-instructions');
if (systemInstructions) {
    // Retrieve the computed display style of the system instructions element
    const computedDisplay = window.getComputedStyle(systemInstructions).display;

    // If the element is currently displayed (not 'none'), hide it; otherwise, revert to default
    if (computedDisplay !== 'none') {
        systemInstructions.style.display = 'none';
    } else {
        systemInstructions.style.display = '';
    }
}