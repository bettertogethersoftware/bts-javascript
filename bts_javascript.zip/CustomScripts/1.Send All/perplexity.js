﻿/*** perplexity ***/
//Validated: 2025-02-19
var targetUrl = "perplexity";
const currentUrlLowerCase = window.location.href.toLowerCase();

if (!currentUrlLowerCase.includes(targetUrl))
    return;
/***************/
// Select the textarea by its placeholder attribute (as in the given HTML)
const textarea = document.querySelector('textarea[placeholder]');
if (textarea) {
    // Focus the textarea.
    textarea.focus();

    // Define the text to insert.
    const insertText = '^TEXT^';

    // Update the textarea's value using the native setter.
    const nativeSetter = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value').set;
    nativeSetter.call(textarea, textarea.value + insertText);

    // Dispatch an InputEvent to simulate real user input.
    const inputEvent = new InputEvent('input', {
        bubbles: true,
        cancelable: true,
        data: insertText,
        inputType: 'insertText'
    });
    textarea.dispatchEvent(inputEvent);

    // Wait briefly before attempting to click the send button.
    setTimeout(() => {
        // Define button selectors. Here we use the aria-label attribute from the provided button.
        const buttonSelectors = [
            'button[aria-label="Submit"]'
            // Additional selectors can be added here if needed.
        ];

        let buttonClicked = false;
        for (const selector of buttonSelectors) {
            const button = document.querySelector(selector);
            if (button) {
                button.click();
                buttonClicked = true;
                break;
            }
        }
        if (!buttonClicked) {
            console.error("Error: Send button not found");
        }
    }, 500);
} else {
    console.error("Error: Textarea not found");
}
